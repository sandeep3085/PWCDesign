import { Component, ViewChild, ViewEncapsulation } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import { Router, NavigationEnd } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent {
  title = 'PWC Design';
  @ViewChild('matMenuTrigger') matMenuTrigger: MatMenuTrigger;
  public href: string = "";
  constructor(private router: Router) {
  // this.href = this.router.url;
  //   console.log(this.router.url);
   // Detect current route
   router.events.subscribe(val => {
    if (val instanceof NavigationEnd) {
      console.log(val.url);
      this.href = val.url;
      this.href = this.href.replace(/\//g, " ");
    }
})
  }
  ngOnInit() {
    
}
  // openMyMenu() {
  //   this.matMenuTrigger.openMenu();

  // } 
  // closeMyMenu() {
  //   this.matMenuTrigger.closeMenu();
  // }

}
