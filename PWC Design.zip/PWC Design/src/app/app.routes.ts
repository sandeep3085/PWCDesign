import { Routes } from '@angular/router';
import { AppComponent } from './app.component';

export const appRoutes: Routes = [
  {
    path: '',
    component : AppComponent
  },
  {
    path: 'UX99',
    component : AppComponent
  },
  {
    path: 'TY96',
    component : AppComponent
  },
  {
    path: 'TPG2',
    component : AppComponent
  },
  {
    path: 'YU89',
    component : AppComponent
  }
]